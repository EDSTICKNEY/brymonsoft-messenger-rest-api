# Nodejs
1.npm install
2.node index 
3.http://127.0.0.1:3000/

Requeired active mysql server.