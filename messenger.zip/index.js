var fs = require('fs');
var express = require('express');
var session = require('express-session');
var app = express();
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
app.set('view engine', 'ejs');
app.use(session({
  secret: 'eds_massenger',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: true }
}));

const mysql = require("mysql");

const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  database: "messenger_db",
  password: ""
});


connection.connect(function(err){
   if (err) {
     return console.error("Ошибка: " + err.message);
   }
   else{
     console.log("Подключение к серверу MySQL успешно установлено");
   }
});




//Load page rendering
app.get('', function(req,res){
  res.render('login', {});
});

app.post('/main', urlencodedParser, async function(req, res) {

  let query_result = {};
  query_result = (query_str) => {
    return new Promise ((resolve, reject) => {
      connection.query(query_str, function (error, results) {
        if (error) {
          return reject(error);
        } else {
          return resolve(results);
        }
      });
    });
  };

  var login_result = await query_result('SELECT * FROM `user` WHERE `name` = "' + req.body.login + '"');
  login_result.forEach((item) => {
    if (item['ID']!='') {
      req.session.user_id=item['ID'];
    }
  });

  if (!req.session.user_id) {
    var insert_result = await query_result(`INSERT INTO user (name, password) values ('${req.body.login}', '${req.body.password}')`);
    req.session.user_id=insert_result.insertId;
  }

  console.log(req.session.user_id);

  var user_data = await query_result('SELECT * from `user`');
  var dialog_data = await query_result('SELECT * FROM `dialog` where users LIKE "%'+req.session.user_id+';%"');

    res.render('main', {user_data: user_data, dialog_data: dialog_data});

});
//linteneng for 127.0.0.1:3000
app.listen(3000);
