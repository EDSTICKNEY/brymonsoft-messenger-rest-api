var express = require('express');
var app = express();

var mysqlAdmin = require('node-mysql-admin');
app.use(mysqlAdmin(app));
app.listen(3000);

/* 

const mysql = require("mysql");

const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  database: "messenger_db",
  password: ""
});


connection.connect(function(err){
   if (err) {
     return console.error("Ошибка: " + err.message);
   }
   else{
     console.log("Подключение к серверу MySQL успешно установлено");
   }
});

var values = ["test", "test"];
var query = connection.query('INSERT INTO user (name, password) values (?)', [values], function (err, row, field) {
  if (err) throw err;
  // Neat!
});
*/
