To start server you should write in Nodejs terminal:
1."npm install"
2."node index"
Then go to the 127.0.0.1:3000

Enjoy
